<?php

$salt = "poivre";

?>